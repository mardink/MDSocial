<?php
	// no direct access
	defined('_JEXEC') or die('Restricted access');
	?>
				<div class="<?php echo $moduleclass_sfx ?>">
		<?php 
	$langSite = substr($params->get('locale'), 0, 2);
	if ($langSite != '') {
		$langSite .= '/';
	}
	
	echo 'Test MDSocial Test'